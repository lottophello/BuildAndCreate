from random import choice,randint
from ursina import *
from perlin_noise import PerlinNoise
import random
from ursina.prefabs.first_person_controller import FirstPersonController
from ursina.shaders import lit_with_shadows_shader
from ursina.prefabs.health_bar import HealthBar
app = Ursina(title='Строй и создавай ')
noise = PerlinNoise (octaves=1,seed=random.randint(1,1000000)) 
grass_texture = load_texture("grass.png")
stone_texture = load_texture("Stone.png")
brick_texture = load_texture("Brick.png")
wood_texture = load_texture("wood_oak.png")
glass_texture = load_texture("glass.png")
sky_texture = load_texture("skybox.png")
sand_texture = load_texture("sand.png")
water_texture = load_texture("water.png")
arm_texture = load_texture("Arm_Texture.png")
window.exit_button.visible = False
block_pick = 1
list_tex = [grass_texture,wood_texture,brick_texture,stone_texture]
scene.fog_density=(0.095)
 
# scene, как и window, тоже один из основных элементов библиотеки. Иногда его можно встретить в параметре наследования parent. Хотя, по моему опыту, его использование скорее опционально, чем обязательно. 

scene.fog_color=color.white 
 
def update():
    global block_pick
    if held_keys["left mouse"] or held_keys["right mouse"]:
        hand.active()
    else:
        hand.passive()
 
    if held_keys["1"]: block_pick = 1
    if held_keys["2"]: block_pick = 2
    if held_keys["3"]: block_pick = 3
    if held_keys["4"]: block_pick = 4
    if held_keys["5"]: block_pick = 5
    if held_keys["6"]: block_pick = 6
    if held_keys["7"]: block_pick = 7
    if held_keys["q"]:player.position = Vec3(0,8,0)
    if held_keys["0"]: quit()
 
 
 
class Sky(Entity):
    def __init__(self):
        super().__init__(
            parent=scene,
            model="Sphere",
            texture=sky_texture,
            scale=90,
            double_sided=True
        )
 
 
 
class Hand(Entity):
    def __init__(self):
        super().__init__(
            parent=camera.ui,
            model="cube",
            texture=arm_texture,
            scale=0.2,
            rotation=Vec3(150, -10, 0),
            position=Vec2(0.4, -0.6)
        )
 
    def active(self):
        self.position = Vec2(0.3, -0.5)
    def passive(self):
        self.position = Vec2(0.4, -0.6)
class Voxel(Button):
    def __init__(self, position=(0, 0, 0), texture=random.choice(list_tex) ):
        super().__init__(
            parent=scene,
            position=position,
            model="cube",
            origin_y=0.7,
            texture=texture,
            color=color.color(0, 0, random.uniform(1, 0.9)),
            highlight_color=color.light_gray,
            scale=1
        )
 
 
    def input(self, key):
        if self.hovered:
            if key == "right mouse down":
                if block_pick == 1: voxel = Voxel(position=self.position + mouse.normal, texture=grass_texture)
                if block_pick == 2: voxel = Voxel(position=self.position + mouse.normal, texture=stone_texture)
                if block_pick == 3: voxel = Voxel(position=self.position + mouse.normal, texture=brick_texture)
                if block_pick == 4: voxel = Voxel(position=self.position + mouse.normal, texture=wood_texture) 
                if block_pick == 5: voxel = Voxel(position=self.position + mouse.normal, texture=glass_texture)
                if block_pick == 6: voxel = Voxel(position=self.position + mouse.normal, texture=sand_texture) 
                if block_pick == 7: voxel = Voxel(position=self.position + mouse.normal, texture=water_texture)
            if key == "left mouse down":
                destroy(self)
for z in range(-30,30):
    for x in range(-30,30):
        y = noise([x * .1,z * .1])
        y = math.floor(y * 7.5)
        voxel = Voxel(position=(x,y,z),texture = grass_texture) 
player = FirstPersonController()
sky = Sky()
hand = Hand()
 
app.run()
